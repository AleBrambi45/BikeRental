Config = {}

--#### Blips ####--
Config.Blips = {
    {title="Bike", colour = 37, id = 226, x = -1034.12, y = -2730.79, z = 19.08 + 1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = 168.15, y = -1009.96, z = 28.33 + 1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = -1102.54, y = -1699.23, z = 3.40 + 1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = -1090.86, y = -265.41, z = 36.78 + 1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = 804.09, y = -2132.81, z = 28.40 + 1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = 1232.0, y = 2725.5, z = 37.03 +1, width = 0.8},
    {title="Bike", colour = 37, id = 226, x = 144.46, y = 6576.75, z = 30.90 + 1, width = 0.8}
}


--#### Bikes ####--
Config.Bikes = {
    {name = "BMX", model = "bmx", price = 50, imageName = "bmx.png"},
    {name = "Scorcher", model = "scorcher", price = 50, imageName = "scorcher.png"},
    {name = "Fixter", model = "fixter", price = 50, imageName = "fixter.png"},
    {name = "Tribike", model = "tribike", price = 50, imageName = "tribike.png"},
    {name = "Tribike 2", model = "tribike2", price = 50, imageName = "tribike2.png"},
    {name = "Tribike 3", model = "tribike3", price = 50, imageName = "tribike3.png"},
}

Config.Currency = "$"
Config.GridSystem = true -- GRIDSYSTEM 0.00ms without 0.03

--#### MESSAGES ####--
Config.OpenMenu = "Press ~INPUT_CONTEXT~ to rent a bike"
Config.NoMoney = "You don't have enough money"
Config.Success = "You have rented a bike"